const express = require('express');
const axios = require('axios');
var bodyParser = require('body-parser');
var app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json())

// Azure Logic App URL
const logicAppUrl = 'https://prod-15.northcentralus.logic.azure.com:443/workflows/55096ecdbb0f47d08d8620847433a330/triggers/manual/paths/invoke?api-version=2016-10-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=vnU0kKnsqcqiSsHlD90GMF_b5L2_zKEbZWvoY3wCmmE';

// Initialize Express app
const PORT = 3000;

// PAYLOAD
const rulesArray = {
  data :[
    {
      page: "borrowerData",
      condition: {
        leftOperand: 700,
        rightOperand:"creditScore" ,
        operator: "<"
      },
      actions: {
        actionType: "modifyWorkflow",
        page: {
          pageAction: "skip",
          pageName: "income"
        },
        fields: []
      }
    },

    {
        page: "borrowerData",
        condition: {
          leftOperand: "citizenShip",
          rightOperand: 700,
          operator: "<"
        },
        actions: {
          actionType: "modifyWorkflow",
          page: {
            pageAction: "skip",
            pageName: "income"
          },
          fields: []
        }
      },
    {
      page: "borrowerData",
      condition: {
        leftOperand: "citizenShip",
        rightOperand: "USA",
        operator: "="
      },
      actions: {
        actionType: "modifyWorkflow",
        page: {
          pageAction: "skip",
          pageName: "demographics"
        },
        fields: []
      }
    }
  ]
}; // END OF PAYLOAD

// List of valid current pages
const validPages = ['Employment', 'creditCheck', 'declarations','borrowerData', 'demographics', 'Options', 'Summary', 'Soft Credit Check', 'Overview', 'SoftCheck'
]; // Add other valid pages as needed


const { validateVariables, validateSyntax, validateCreditScore, validateLogic, requiredFields } = require('./Validator.js');

// Time measurement function
function measureTime(start, end) {
  const timeTaken = end - start;
  console.log(`Time taken: ${timeTaken} ms`);
  return timeTaken;
}

// Function to validate the currentPage
function validateCurrentPage(payload) {
    const { currentPage } = payload;
  
    // Check if currentPage is empty or not in the validPages list
    if (!currentPage || !validPages.includes(currentPage)) {
      throw new Error(`Invalid or empty currentPage: ${currentPage}.It must be one of the following: ${validPages.join(', ')}.`);
    }
  }

  function validateCitizenShip(payload) {
    // Define the list of valid citizenShip values
    const validCitizenShipValues = ['US_CITIZEN', 'PERMANENT_RESIDENT', 'NON_RESIDENT'];
  
    // Check if the citizenShip field is empty or not within the valid values
    if (!payload.borrowerData.citizenShip || !validCitizenShipValues.includes(payload.borrowerData.citizenShip)) {
      throw new Error(`Invalid or missing citizenShip value. It must be one of: ${validCitizenShipValues.join(', ')}`);
    }
  }

  function validateSelectedProduct(payload) {
    const validProducts = ['FHA', 'VA', 'USDA', 'Conventional']; // Add valid products as needed
    const { selectedProduct } = payload.borrowerData;
  
    if (!selectedProduct || !validProducts.includes(selectedProduct)) {
      throw new Error(`Invalid selectedProduct: ${selectedProduct}. It must be one of the following: ${validProducts.join(', ')}`);
    }
  }


  // function getAllKeys(obj) {
  //   let keys = [];
  
  //   function extractKeys(value) {
  //     if (typeof value === 'object' && value !== null) {
  //       // If the value is an array, iterate over each element
  //       if (Array.isArray(value)) {
  //         value.forEach(item => extractKeys(item));
  //       } else {
  //         // If it's an object, add its keys and call recursively
  //         Object.keys(value).forEach(key => {
  //           keys.push(key);
  //           extractKeys(value[key]);
  //         });
  //       }
  //     }
  //   }
  
  //   extractKeys(obj);
  //   return keys;
  // }
  
  // // Get all keys
  // const validLeftOperands = getAllKeys(payload);  




  function getAllKeysAndValues(obj) {
    let keys = [];
    let values = [];
  
    function extractKeysAndValues(value) {
      if (typeof value === 'object' && value !== null) {
        if (Array.isArray(value)) {
          // If it's an array, iterate over each element
          value.forEach(item => extractKeysAndValues(item));
        } else {
          // If it's an object, collect both keys and values
          Object.keys(value).forEach(key => {
            keys.push(key);          // Store the key
            extractKeysAndValues(value[key]); // Recurse on the value
          });
        }
      } else {
        // If it's a primitive value, store the value
        values.push(value);
      }
    }
  
    extractKeysAndValues(obj);
    return { keys, values };
  }
  
  // Usage example:
  const result = getAllKeysAndValues(rulesArray);
  const validLeftOperands = result.keys;
  const validRightOperands = result.values;
  







  function validateRulesArray(payload) {
    const validPages = ['Employment', 'creditCheck', 'declarations','borrowerData', 'demographics', 'Options', 'Summary', 'Soft Credit Check', 'Overview', 'SoftCheck'];

    const validOperators = ['=', '>', '<', '>=', '<=', 'GREATERTHAN','greaterthan', 'LESSTHAN', 'lessthan'];


    rulesArray.data.forEach((rule, index) => {
      const { page, condition, actions } = rule;


      
  
      // Validate 'page' field
      if (!page || !validPages.includes(page)) {
        throw new Error(`Invalid 'page' at rule ${index}: ${page}. It must be one of the following: ${validPages.join(', ')}`);
      }
  
      // Validate 'condition' object
      if (!condition || typeof condition !== 'object') {
        throw new Error(`Missing or invalid 'condition' object at rule ${index}`);
      }
  
      const { leftOperand, rightOperand, operator } = condition;
  
      // Validate 'leftOperand' (it should be a non-empty string)
      if ((typeof leftOperand !== 'string' || leftOperand.trim() === '') && !isValidNumber(leftOperand)) {
        throw new Error(`Invalid 'leftOperand' at rule ${index}: must be a non-empty string`);
      }
  
      // Validate 'rightOperand' (it should not be undefined or null)
      if (typeof rightOperand === 'undefined' || rightOperand === null) {
        throw new Error(`'rightOperand' is missing or invalid at rule ${index}`);
      }
  
      // Validate 'operator' (it should be one of the valid operators)
      if (!operator || !validOperators.includes(operator.toUpperCase())) {
        throw new Error(`Invalid 'operator' at rule ${index}: ${operator}. It must be one of ${validOperators.join(', ')}`);
      }
  
      // Validate 'actions' object
      if (!actions || typeof actions !== 'object') {
        throw new Error(`Missing or invalid 'actions' object at rule ${index}`);
      }
  
      const { actionType, page: actionPage, fields } = actions;
  
      // Validate 'actionType' (it should be a non-empty string)
      if (typeof actionType !== 'string' || actionType.trim() === '') {
        throw new Error(`Invalid 'actionType' at rule ${index}: must be a non-empty string`);
      }
  
      // Validate 'page' within 'actions' (must be a valid object with 'pageAction' and 'pageName')
      if (!actionPage || typeof actionPage !== 'object' || !actionPage.pageAction || !actionPage.pageName) {
        throw new Error(`Invalid 'page' within 'actions' at rule ${index}: must contain 'pageAction' and 'pageName'`);
      }
  
      // Validate 'fields' array within 'actions' (it should be an array)
      if (!Array.isArray(fields)) {
        throw new Error(`'fields' should be an array at rule ${index}`);
      }
    });
  }

  function isValidNumber(value) {
    // Convert the value to a number
    const num = Number(value);
  
    // Check if the value is a number and has at most 5 digits
    if (!isNaN(num) && Number.isInteger(num) && num >= -99999 && num <= 99999) {
      return true;
    }
    
    return false;
  }

// Function to validate leftOperand values in the rulesArray
function validateLeftOperandInRulesArray(payload) {
  // Ensure that rulesArray is present in the payload
  if (!rulesArray.data || !Array.isArray(rulesArray.data)) {
    throw new Error("Invalid or missing rulesArray in the payload.");
  }

  // Iterate over each rule in the rulesArray
  rulesArray.data.forEach((rule, index) => {
    const { condition } = rule;

    // Ensure condition and leftOperand exist
    if (!condition || !condition.leftOperand) {
      throw new Error(`Missing condition or leftOperand at rule ${index}`);
    }

    // Ensure condition and rightOperand exist
    if (!condition || !condition.rightOperand) {
      throw new Error(`Missing condition or rightOperand at rule ${index}`);
    }

    const { leftOperand } = condition;

    // Check if leftOperand is not valid
    if (!validLeftOperands.includes(leftOperand) && !isValidNumber(leftOperand)) {
      throw new Error(`Invalid leftOperand at rule ${index}. Allowed values are: ${validLeftOperands.join(', ')}`);
    }
    const { rightOperand} = condition;

     // Check if rightOperand is not valid
     if (!validRightOperands.includes(rightOperand) && !isValidNumber(rightOperand)) {
      throw new Error(`Invalid rightOperand at rule ${index}. Allowed values are: ${validRightOperands.join(', ')}`);
    }
  });
}
  

function validateContradictingOperators(payload) {
    const operators = ['=', '>', '<', '>=', '<=', 'GREATERTHAN', 'greaterthan', 'LESSTHAN', 'lessthan'];
  
    rulesArray.data.forEach((rule, index) => {
      const operator = rule.condition.operator;
  
      // Check if the operator is valid
      if (!operators.includes(operator)) {
        throw new Error(`Invalid operator at rule ${index}: ${operator}`);
      }
  
      // Loop through each rule to check for contradicting operators
      rulesArray.data.forEach((innerRule, innerIndex) => {
        if (index !== innerIndex && rule.condition.leftOperand === innerRule.condition.leftOperand) {
          const innerOperator = innerRule.condition.operator;
          if (operator !== innerOperator) {
            throw new Error(`Contradicting operators found between rule ${index} and rule ${innerIndex}`);
          }
        }
      });
    });
  }
  
  



// Main function to validate the entire payload
function validatePayload(payload) {
  const finalPayload = Object.assign({}, payload, rulesArray);
  const startTime = Date.now();  // Start time for validation


  try {
    validateVariables(finalPayload);
    validateCurrentPage(finalPayload);
    validateSyntax(finalPayload);
    validateCitizenShip(finalPayload);
    validateCreditScore(finalPayload);
    validateRulesArray(finalPayload);
    validateLeftOperandInRulesArray(finalPayload);
    validateContradictingOperators(finalPayload);
    validateSelectedProduct(finalPayload);
    validateLogic(finalPayload);
    console.log("Payload is valid.");
    const endTime = Date.now();  // End time for validation
    measureTime(startTime, endTime);  // Measure validation time
  } catch (error) {
    const endTime = Date.now();  // End time even if validation fails
    measureTime(startTime, endTime,"dffdsd");  // Measure validation time
    console.error("Validation Error:", error.message);
    throw error;
  }
}

// Function to trigger the Azure Logic App if the payload is valid
async function triggerLogicApp(finalPayload) {
const startTime = Date.now();  // Start time for Logic App trigger

  try {
    const response = await axios.post(logicAppUrl, finalPayload, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
    const endTime = Date.now();  // End time for Logic App trigger
    measureTime(startTime, endTime);  // Measure time taken for Logic App response
    
    console.log('Logic App triggered successfully:', response.data);
    return response.data;
  } catch (error) {
    const endTime = Date.now();  // End time for Logic App trigger (error case)
    measureTime(startTime, endTime);  // Measure time even if the Logic App trigger fails
    
    console.error('Error triggering Logic App:', error.response ? error.response.data : error.message);
    throw new Error('Failed to trigger Logic App.');
  }
}

// Express endpoint to accept and validate payload
app.post('/process-payload', async (req, res) => {

  const payload = req.body;

  try {
    // Validate the payload
    validatePayload(payload);

    // Trigger the Logic App if the payload is valid
    const logicAppResponse = triggerLogicApp(payload);

    // Send success response
    res.status(200).json({
      message: 'Payload is valid and Logic App triggered successfully.',
      logicAppResponse
    });
  } catch (error) {
    // Send error response if validation or Logic App triggering fails
    res.status(400).json({
      message: 'Validation failed or Logic App triggering failed.',
      error: error.message
    });
  }
});

// Start the Express server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});


// Execute validation and trigger the logic app if validation passes
try {
  validatePayload(payload);
  triggerLogicApp(finalPayload);
} catch (error) {
  console.error('Validation failed. Not triggering Logic App.');
}
