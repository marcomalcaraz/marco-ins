// Validator.js


// List of valid current pages
const validPages = ['Employment', 'creditCheck', 'declarations']; // Add other valid pages as needed



// Function to validate the presence of required variables in the payload
function validateVariables(payload) {
  if (!payload) {
    throw new Error('Payload is null or undefined.');
}

  const requiredFields = ['currentPage', 'borrowerData', 'rulesArray','data', 'SUCCESS', 'fields', 'skip', 'step', 'rules', 'rule', 'response', 'borrowerData', 'citizenShip', 'creditScore', 'selectedProduct', 'va', 'Condition check', 'page'];
    let fieldFound = false;
  
    requiredFields.forEach(field => {
      
      if (!payload.hasOwnProperty(field) || payload[field] === "" || payload[field] === null || (Array.isArray(payload[field]) && payload[field].length === 0)) {
        missingOrEmptyFields.push(field); // Add the field to the list of missing or empty fields
        fieldFound = true;
      }
    });
  
    if (!fieldFound) {
      throw new Error(`None of the required fields are present in the payload.`);
    }
  }

  let missingOrEmptyFields = [];
  // If any required fields are missing or empty, throw an error
  if (missingOrEmptyFields.length > 0) {
    throw new Error(`The following required fields are missing or empty: ${missingOrEmptyFields.join(', ')}`);
  }
  
  // Function to validate the syntax of conditions in the rules
  function validateSyntax(payload) {
    const validOperators = ['=', '>', '<', '>=', '<=', 'GREATERTHAN', 'LESSTHAN'];

    // console.log("REUASDFSDFSDFSD " + JSON.stringify(payload));
    payload.data.forEach((rule, index) => {
      const { leftOperand, rightOperand, operator, page } = rule.condition;
      const normalizedOperator = operator.toUpperCase();
  
      if (page === 'declarations' && operator !== '=') {
        throw new Error(`For the "declarations" page, the operator must be "=" at rule ${index}`);
      }

    // Check if page is not an empty string
    if (page === "") {
      throw new Error(`Error! - Page does not have any value at rule ${index}`);
    }

    // Check if page is "creditCheck" and ensure it's not null
    if (page === 'creditCheck' && page === null) {
        throw new Error(`For the "creditCheck" page, page value must not be null at rule ${index}`);
    }

      if (!validOperators.includes(normalizedOperator)) {
        throw new Error(`Invalid operator at rule ${index}: ${operator}`);
      }
  
      if (typeof leftOperand === 'undefined') {
        throw new Error(`leftOperand must be a string at rule ${index}`);
      }
  
      if (['GREATERTHAN', 'LESSTHAN', '>', '<', '>=', '<='].includes(normalizedOperator)) {
        const numRightOperand = Number(rightOperand);
  
        // if (isNaN(numRightOperand)) {
        //   throw new Error(`Invalid number at rule ${index}: ${rightOperand}`);
        // }
  
        if (numRightOperand > 1500) {
          throw new Error(`Huge number detected at rule ${index}: ${rightOperand}`);
        }
      }
    });
  }
  
  // Function to validate the credit score in the payload
  function validateCreditScore(payload) {
    const creditScore = payload.borrowerData.creditScore;
  
    if (typeof creditScore === 'undefined') {
      throw new Error(`Missing creditScore in borrowerData.`);
    }
  
    const numCreditScore = Number(creditScore);
  
    if (isNaN(numCreditScore)) {
      throw new Error(`Invalid creditScore: ${creditScore}. It must be a number.`);
    }
  
    if (numCreditScore < 700 || numCreditScore > 1500) {
      throw new Error(`Credit score must be between 700 and 1500. Current value: ${creditScore}`);
    }
  }
  
  // Function to validate logic and detect any contradictions in the rules
  function validateLogic(payload) {
    const seenConditions = new Set();
  
    payload.data.forEach((rule, index) => {
      const conditionString = `${rule.condition.leftOperand}${rule.condition.operator}${rule.condition.rightOperand}`;
  
      if (seenConditions.has(conditionString)) {
        throw new Error(`Contradicting rule detected at index ${index}: ${conditionString}`);
      }
  
      seenConditions.add(conditionString);
    });
  
    const hasContradictingRule = payload.data.length !== seenConditions.size;
    if (hasContradictingRule) {
      throw new Error('Contradicting rules detected. Please resolve them.');
    }
  }
  
  module.exports = {
    validateVariables,
    validateSyntax,
    validateCreditScore,
    validateLogic
  };
  