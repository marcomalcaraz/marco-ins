const axios = require('axios');

// Azure Logic App URL
const logicAppUrl = 'https://prod-15.northcentralus.logic.azure.com:443/workflows/55096ecdbb0f47d08d8620847433a330/triggers/manual/paths/invoke?api-version=2016-10-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=vnU0kKnsqcqiSsHlD90GMF_b5L2_zKEbZWvoY3wCmmE';

// PAYLOAD
const payload = {
  currentPage: "Employment",
  borrowerData: {
    citizenShip: "US_CITIZEN",
    creditScore: 700,
    selectedProduct: "VA",
    va: false
  },
  rulesArray: [
    {
      page: "borrowerData",
      condition: {
        leftOperand: 700,
        rightOperand:"creditScore" ,
        operator: "<"
      },
      actions: {
        actionType: "modifyWorkflow",
        page: {
          pageAction: "skip",
          pageName: "income"
        },
        fields: []
      }
    },

    {
        page: "borrowerData",
        condition: {
          leftOperand: "moiz",
          rightOperand: 700,
          operator: "<"
        },
        actions: {
          actionType: "modifyWorkflow",
          page: {
            pageAction: "skip",
            pageName: "income"
          },
          fields: []
        }
      },
    {
      page: "borrowerData",
      condition: {
        leftOperand: "citizenShip",
        rightOperand: "USA",
        operator: "="
      },
      actions: {
        actionType: "modifyWorkflow",
        page: {
          pageAction: "skip",
          pageName: "demographics"
        },
        fields: []
      }
    }
  ]
}; // END OF PAYLOAD

// List of valid current pages
const validPages = ['Employment', 'creditCheck', 'declarations','borrowerData', 'demographics', 'Options', 'Summary', 'Soft Credit Check', 'Overview', 'SoftCheck'
]; // Add other valid pages as needed



const { validateVariables, validateSyntax, validateCreditScore, validateLogic, requiredFields } = require('./Validator.js');


// Function to validate the currentPage
function validateCurrentPage(payload) {
    const { currentPage } = payload;
  
    // Check if currentPage is empty or not in the validPages list
    if (!currentPage || !validPages.includes(currentPage)) {
      throw new Error(`Invalid or empty currentPage: ${currentPage}.It must be one of the following: ${validPages.join(', ')}.`);
    }
  }

  function validateCitizenShip(payload) {
    // Define the list of valid citizenShip values
    const validCitizenShipValues = ['US_CITIZEN', 'PERMANENT_RESIDENT', 'NON_RESIDENT'];
  
    // Check if the citizenShip field is empty or not within the valid values
    if (!payload.borrowerData.citizenShip || !validCitizenShipValues.includes(payload.borrowerData.citizenShip)) {
      throw new Error(`Invalid or missing citizenShip value. It must be one of: ${validCitizenShipValues.join(', ')}`);
    }
  }

  function validateSelectedProduct(payload) {
    const validProducts = ['FHA', 'VA', 'USDA', 'Conventional']; // Add valid products as needed
    const { selectedProduct } = payload.borrowerData;
  
    if (!selectedProduct || !validProducts.includes(selectedProduct)) {
      throw new Error(`Invalid selectedProduct: ${selectedProduct}. It must be one of the following: ${validProducts.join(', ')}`);
    }
  }


  function getAllKeys(obj) {
    let keys = [];
  
    function extractKeys(value) {
      if (typeof value === 'object' && value !== null) {
        // If the value is an array, iterate over each element
        if (Array.isArray(value)) {
          value.forEach(item => extractKeys(item));
        } else {
          // If it's an object, add its keys and call recursively
          Object.keys(value).forEach(key => {
            keys.push(key);
            extractKeys(value[key]);
          });
        }
      }
    }
  
    extractKeys(obj);
    return keys;
  }
  
  // Get all keys
  const validLeftOperands = getAllKeys(payload);  

  function validateRulesArray(payload) {
    const validPages = ['Employment', 'creditCheck', 'declarations','borrowerData', 'demographics', 'Options', 'Summary', 'Soft Credit Check', 'Overview', 'SoftCheck'];

    const validOperators = ['=', '>', '<', '>=', '<=', 'GREATERTHAN','greaterthan', 'LESSTHAN', 'lessthan'];


    payload.rulesArray.forEach((rule, index) => {
      const { page, condition, actions } = rule;


      
  
      // Validate 'page' field
      if (!page || !validPages.includes(page)) {
        throw new Error(`Invalid 'page' at rule ${index}: ${page}. It must be one of the following: ${validPages.join(', ')}`);
      }
  
      // Validate 'condition' object
      if (!condition || typeof condition !== 'object') {
        throw new Error(`Missing or invalid 'condition' object at rule ${index}`);
      }
  
      const { leftOperand, rightOperand, operator } = condition;
  
      // Validate 'leftOperand' (it should be a non-empty string)
      if ((typeof leftOperand !== 'string' || leftOperand.trim() === '') && !isValidNumber(leftOperand)) {
        throw new Error(`Invalid 'leftOperand' at rule ${index}: must be a non-empty string`);
      }
  
      // Validate 'rightOperand' (it should not be undefined or null)
      if (typeof rightOperand === 'undefined' || rightOperand === null) {
        throw new Error(`'rightOperand' is missing or invalid at rule ${index}`);
      }
  
      // Validate 'operator' (it should be one of the valid operators)
      if (!operator || !validOperators.includes(operator.toUpperCase())) {
        throw new Error(`Invalid 'operator' at rule ${index}: ${operator}. It must be one of ${validOperators.join(', ')}`);
      }
  
      // Validate 'actions' object
      if (!actions || typeof actions !== 'object') {
        throw new Error(`Missing or invalid 'actions' object at rule ${index}`);
      }
  
      const { actionType, page: actionPage, fields } = actions;
  
      // Validate 'actionType' (it should be a non-empty string)
      if (typeof actionType !== 'string' || actionType.trim() === '') {
        throw new Error(`Invalid 'actionType' at rule ${index}: must be a non-empty string`);
      }
  
      // Validate 'page' within 'actions' (must be a valid object with 'pageAction' and 'pageName')
      if (!actionPage || typeof actionPage !== 'object' || !actionPage.pageAction || !actionPage.pageName) {
        throw new Error(`Invalid 'page' within 'actions' at rule ${index}: must contain 'pageAction' and 'pageName'`);
      }
  
      // Validate 'fields' array within 'actions' (it should be an array)
      if (!Array.isArray(fields)) {
        throw new Error(`'fields' should be an array at rule ${index}`);
      }
    });
  }

  function isValidNumber(value) {
    // Convert the value to a number
    const num = Number(value);
  
    // Check if the value is a number and has at most 5 digits
    if (!isNaN(num) && Number.isInteger(num) && num >= -99999 && num <= 99999) {
      return true;
    }
    
    return false;
  }

// Function to validate leftOperand values in the rulesArray
function validateLeftOperandInRulesArray(payload) {
  // Ensure that rulesArray is present in the payload
  if (!payload.rulesArray || !Array.isArray(payload.rulesArray)) {
    throw new Error("Invalid or missing rulesArray in the payload.");
  }

  // Iterate over each rule in the rulesArray
  payload.rulesArray.forEach((rule, index) => {
    const { condition } = rule;

    // Ensure condition and leftOperand exist
    if (!condition || !condition.leftOperand) {
      throw new Error(`Missing condition or leftOperand at rule ${index}`);
    }

    const { leftOperand } = condition;

    // Check if leftOperand is not valid
    if (!validLeftOperands.includes(leftOperand) && !isValidNumber(leftOperand)) {
      throw new Error(`Invalid leftOperand at rule ${index}. Allowed values are: ${validLeftOperands.join(', ')}`);
    }
  });
}
  

function validateContradictingOperators(payload) {
    const operators = ['=', '>', '<', '>=', '<=', 'GREATERTHAN', 'greaterthan', 'LESSTHAN', 'lessthan'];
  
    payload.rulesArray.forEach((rule, index) => {
      const operator = rule.condition.operator;
  
      // Check if the operator is valid
      if (!operators.includes(operator)) {
        throw new Error(`Invalid operator at rule ${index}: ${operator}`);
      }
  
      // Loop through each rule to check for contradicting operators
      payload.rulesArray.forEach((innerRule, innerIndex) => {
        if (index !== innerIndex && rule.condition.leftOperand === innerRule.condition.leftOperand) {
          const innerOperator = innerRule.condition.operator;
          if (operator !== innerOperator) {
            throw new Error(`Contradicting operators found between rule ${index} and rule ${innerIndex}`);
          }
        }
      });
    });
  }
  
  

// Main function to validate the entire payload
function validatePayload(payload) {
  try {
    validateVariables(payload);
    validateCurrentPage(payload);
    validateSyntax(payload);
    validateCitizenShip(payload); // Include the citizenShip validation
    validateCreditScore(payload);
    validateRulesArray(payload);
    validateLeftOperandInRulesArray(payload);
    validateContradictingOperators(payload)
    validateSelectedProduct(payload);
    validateLogic(payload);
    console.log("Payload is valid.");
  } catch (error) {
    console.error("Validation Error:", error.message);
    throw error; // Re-throw the error to prevent further execution
  }
}

// Function to trigger the Azure Logic App if the payload is valid
async function triggerLogicApp(payload) {
  try {
    const response = await axios.post(logicAppUrl, payload, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
    console.log('Logic App triggered successfully:', response.data);
  } catch (error) {
    console.error('Error triggering Logic App:', error.response ? error.response.data : error.message);
  }
}

// Execute validation and trigger the logic app if validation passes
try {
  validatePayload(payload);
  triggerLogicApp(payload);
} catch (error) {
  console.error('Validation failed. Not triggering Logic App.');
}
